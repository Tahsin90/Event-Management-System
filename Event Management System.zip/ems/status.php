<!DOCTYPE html>
<html>
<head>
<!-- ONLINE -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- OFFLINE -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	</head>
<style>
table, th, td {
    border: 1px solid white;
	align : center;
	color:white;
}

h2 {
	
	color : white;
}
body {font-family: Arial, Helvetica, sans-serif;
background-color : black;
width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;}


</style>

<body>



	<!-- ONLINE -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- OFFLINE -->
	<script src="assets/bootstrap/js/jquery.min.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	
	 <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
        
        </div>
        <ul class="nav navbar-nav">
          <li><a href="Home.php">HOME</a></li>
          <li><a href="registration.php">REGISTRATION</a></li>
          <li><a href="login.php">LOGIN</a></li>
          <li><a href="adminlogin.php">Admin Login</a></li>
		   <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   
		   <li><a href=""></a></li>
		  <li><a href=""></a></li>
		   <li><a href=""></a></li>
		  
		  
		  
        </ul>
      </div>
    </nav>
<h2>Booking Status</h2>
</body>

<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eventmanagement";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT OID,Type,Date,Guestno,Budget,Venue,accepted FROM orderevent";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>OID</th><th>Type</th><th>Date</th><th>Guestno</th><th>Budget</th><th>Venue</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["OID"]. "</td><td>" . $row["Type"]. "</td><td>" . $row["Date"]. "</td><td>" . $row["Guestno"]. "</td><td>" . $row["Budget"]. "</td><td>" . $row["Venue"]. "</td></tr>";
	if($row['accepted']=='true'){
echo "hello world";
	}
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?> 


</html>