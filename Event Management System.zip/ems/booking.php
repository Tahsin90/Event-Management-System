
<!DOCTYPE html>


<?php

include ('connection.php');
session_start();
error_reporting(0);


     if($_POST['submit']){
		 
		
	 
	   
     $ueventname = $_POST['eventname'];  
     $ubudget = $_POST['budget'];  
     $udate = $_POST['date'];    
     $uguestno = $_POST['guestno'];  
     $uvenue = $_POST['venue'];  
     $accept="false";
	 $user_id=$_SESSION['loggedinuserid'];
	 echo "User id ".$_SESSION['loggedinuserid'];
    
	 
	 
   
	   $sql = "INSERT into orderevent(`Type`,`Date`,`Guestno`,`Budget`,`Venue`,`accepted`,`CID`)
	   values ('$ueventname','$udate','$uguestno','$ubudget','$uvenue','$accept','$user_id') ";
	   
	 
	   
	   if(mysqli_query($connection,$sql))
	   {
		   echo "success";
	   }
	   
	   else {
		   echo "error ";
	   }
   }
   
   
?>

<html>
<head>
	<title>Registration system PHP and MySQL</title>
	<!-- ONLINE -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- OFFLINE -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	<!-- ONLINE -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- OFFLINE -->
	<script src="assets/bootstrap/js/jquery.min.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	
</head>
<style>

body {
    font-family: Arial, Helvetica, sans-serif;
    background-color: red;
}
h1
{
	color : white;
}

h4
{
	color : white;
	
}
* {
    box-sizing: border-box;
}
.container {
   
    background-color: black;
}



input[type=text], input[type=password], input[type=date] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: white;
}



select
{
	
	width: 100%;
    padding: 15px;
    margin: 6px 0 12px 0;
    display: inline-block;
    border: none;
    background: white;
}

input[type=text]:focus, input[type=password]:focus, input[type=date]:focus {
    background-color: white;
	
    outline: none;
}

/* Overwrite default styles of hr */
hr {
    border: 1px solid black;
    margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

.registerbtn:hover {
    capacity: 1;
}

/* Add a blue text color to links */
a {
    color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
    background-color: black;
    text-align: center;
}

b {
	color:white;
}



</style>

<body>

	 <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
        
        </div>
        <ul class="nav navbar-nav">
          <li><a href="Home.php">HOME</a></li>
          <li><a href="registration.php">REGISTRATION</a></li>
          <li><a href="login.php">LOGIN</a></li>
          <li><a href="adminlogin.php">Admin</a></li>
		   <li><a href="order.php">Order</a></li>
		   <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   
		   <li><a href=""></a></li>
		  <li><a href=""></a></li>
		   <li><a href=""></a></li>
		  
		  
		  
        </ul>
      </div>
    </nav>
	
	
	<form action="booking.php" method="post">
  <div class="container">
    
    <p><h4>Please fill in this form ..</h4></p>
    <hr>

	<label for="eventname"><b>Name of Event</b></label>
	<select name = "eventname">
    <option value="select">select</option>
    <option value="Wedding Ceremony">Wedding Ceremony</option>
    <option value="Birthday Party">Birthday Party</option>
	<option value="Reception">Reception</option>
 	</select><p>
	
	<label for="date"><b>Date</b></label>
    <input type="date" placeholder="Enter Date" name="date" required>
	
	<label for="venue"><b>Venue</b></label>
    <select name = "venue">
    <option value="select">select</option>
    <option value="a">a</option>
    <option value="b">b</option>
	<option value="c">c</option>
 	</select required><p>
	
    <label for="guestno"><b>Number of Guests</b></label>
    <input type="text" placeholder="Enter number of guests" name="guestno" required>
	
	<label for="budget"><b>Budget</b></label>
    <input type="text" placeholder="Enter Budget" name="budget" required>
	
	<input type="submit" name="submit" class="registerbtn" value="Send Booking Request"  onclick="myFunction()">
	
  </div>
  
  <script>
function myFunction() {
    alert("Your request has been sent!!!");
}
</script>


</body>
</html>

