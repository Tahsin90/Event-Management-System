<?php

    $dbhost  = "localhost";
	$dbuser  = "root";
	$dbpass  = "";
	$db = "eventmanagement";
	

$connection = new mysqli ($dbhost,$dbuser,$dbpass,$db);



if($connection->connect_error)
{
	echo "";
}
 
else
{
	echo "";
}

?>