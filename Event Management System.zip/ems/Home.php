<!DOCTYPE html>


<html>

<head>
<title>HOME</title>
<!-- ONLINE -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- OFFLINE -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	
</head>


      
<body>


<!-- ONLINE -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- OFFLINE -->
	<script src="assets/bootstrap/js/jquery.min.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	
	 
	
	 <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
        
        </div>
        <ul class="nav navbar-nav">
          <li><a href="Home.php">Home</a></li>
          <li><a href="registration.php">Registration</a></li>
		  <li><a href="login.php">LOGIN</a></li>
          <li><a href="adminlogin.php">Admin</a></li>
          <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   
		   <li><a href=""></a></li>
		  <li><a href=""></a></li>
		   <li><a href=""></a></li>
		  
		  
		  
        </ul>
      </div>
    </nav>
	


  
</body>

</html>