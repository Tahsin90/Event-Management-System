<!DOCTYPE html>

<?php

include ('connection.php');
error_reporting(0);


     if($_POST['submit']){
	   
     $name = $_POST['name'];  
     $useremail = $_POST['email'];  
     $useraddress = $_POST['address'];    
     $username = $_POST['username'];  
     $userpass = $_POST['passw'];  
   
     $userphn = $_POST['phone'];
	 
	// $name = $useremail = $useraddress = $username = $userphn = "";


	 
   
	   $sql = "INSERT into customerinfo(`Name`,`Address`,`Phone`,`Email`,`Username`,`Password`)
	   values ('$name','$useraddress','$userphn','$useremail','$username','$userpass') ";
	   
	 
	   
	   if(mysqli_query($connection,$sql))
	   {
		   echo "";
	   }
	   
	   else {
		   echo "" ;
	   }
	
	 }
	 
	 	  
   
   
   
?>
<html>
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	


<style>
body {
    font-family: Arial, Helvetica, sans-serif;
    background-color: black;
}
h1
{
	color : white;
}

h4
{
	color : white;
	
}
* {
    box-sizing: border-box;
}
.container {
   
    background-color: black;
}



input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: white;
}

input[type=text]:focus, input[type=password]:focus {
    background-color: white;
	
    outline: none;
}

/* Overwrite default styles of hr */
hr {
    border: 1px solid black;
    margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

.registerbtn:hover {
    capacity: 1;
}

/* Add a blue text color to links */
a {
    color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
    background-color: black;
    text-align: center;
}

b {
	color:white;
}



</style>
</head>
<body>

<!-- ONLINE -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- OFFLINE -->
	<script src="assets/bootstrap/js/jquery.min.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	
	 
	
	 <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
        
        </div>
        <ul class="nav navbar-nav">
          <li><a href="Home">Home</a></li>
          <li><a href="registration.php">Registration</a></li>
		  <li><a href="login.php">LOGIN</a></li>
          <li><a href="adminlogin.php">Admin</a></li>
          <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   
		   <li><a href=""></a></li>
		  <li><a href=""></a></li>
		   <li><a href=""></a></li>
		  
		  
		  
        </ul>
      </div>
    </nav>



<form action="registration.php" method="post">
  <div class="container">
    <h1>Register</h1>
    <p><h4>Please fill in this form to create an account.</h4></p>
    <hr>

	
	<label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>
	
	<label for="address"><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address">
	
    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>
	
	<label for="phone"><b>Phone</b></label>
    <input type="text" placeholder="Enter Phone" name="phone" required>
	
	<label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

    <label for="passw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="passw" required>
	
    
    <hr>
    

    <input type="submit" name="submit" class="registerbtn" value="Register">
  </div>
  
  <div class="container signin">
   <h4><p>Already have an account?</h4> <a href="login.php">Sign in</a></p>
  </div>
</form>

</body>
</html>