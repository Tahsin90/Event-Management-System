
<!DOCTYPE html>


<?php

include ('connection.php');
error_reporting(0);


     if($_POST['submit']){
	   
     $ufood = ""; 
     $food=""; 
	  $uphoto = $_POST['Photographypackages']; 
      $udecoration = $_POST['decoration'];
      $price=0;
      if(!empty($_POST['Fooditems'])){
        foreach($_POST['Fooditems'] as $selected){
          echo $selected."</br>";
          $ufood=$selected;
          if(strcmp($ufood,"a")==0){
            $price+=120;
          }else if(strcmp($ufood,"b")==0){
            $price+=220;
          }else if(strcmp($ufood,"c")==0) {
            $price+=320;
          }
          $food=$food." ".$ufood;
        }
      }
    if(strcmp($uphoto,"a")==0){
      $price+=120;
    }else if(strcmp($uphoto,"b")==0){
      $price+=220;
    }else if(strcmp($uphoto,"c")==0){
      $price+=320;
    }

    if(strcmp($udecoration,"a")==0){
      $price+=120;
    }else if(strcmp($udecoration,"b")==0){
      $price+=220;
    }else if(strcmp($udecoration,"c")==0){
      $price+=320;
    }

	   $sql = "INSERT into orderdetails(`foodname`,`decorationname`,`phptographyname`,`price`)

	   values ('$food','$udecoration','$uphoto','$price') ";
	   
	 
	   
	   if(mysqli_query($connection,$sql))
	   {
		   echo "";
	   }
	   
	   else {
		   echo "" ;
	   }
   }
   
   
?>

<html>
<head>
	<title>Registration system PHP and MySQL</title>
	<!-- ONLINE -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- OFFLINE -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	<!-- ONLINE -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- OFFLINE -->
	<script src="assets/bootstrap/js/jquery.min.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>
<style>

body {
    font-family: Arial, Helvetica, sans-serif;
    background-color: black;
}
h1
{
	color : white;
}

h4
{
	color : white;
	
}
* {
    box-sizing: border-box;
}
.container {
   
    background-color: black;
}



input[type=text], input[type=password], input[type=date] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: white;
	
}

 input[type=checkbox]
 {
	  background-color: white;
	  background: white;
	  color : white;
	  text-color : white;
 }

select
{
	
	width: 100%;
    padding: 15px;
    margin: 6px 0 12px 0;
    display: inline-block;
    border: none;
    background: white;
}

input[type=text]:focus, input[type=password]:focus, input[type=date]:focus {
    background-color: white;
	
    outline: none;
}

/* Overwrite default styles of hr */
hr {
    border: 1px solid black;
    margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}


.registerbtn:hover {
    capacity: 1;
}

/* Add a blue text color to links */
a {
    color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
    background-color: black;
    text-align: center;
}

b {
	color:white;
}



</style>

<body>

	 <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
        
        </div>
        <ul class="nav navbar-nav">
          <li><a href="Home.php">HOME</a></li>
          <li><a href="registration.php">REGISTRATION</a></li>
          <li><a href="login.php">LOGIN</a></li>
          <li><a href="adminlogin">AdminLogin</a></li>
		   <li><a href="order.php">Order</a></li>
		   <li><a href=""></a></li>
		   <li><a href=""></a></li>
		   
		   <li><a href=""></a></li>
		  <li><a href=""></a></li>
		   <li><a href=""></a></li>
		  
		  
		  
        </ul>
      </div>
    </nav>
	
	
	<form action="order.php" method="post">
  <div class="container">
    
    
    <hr>
	
	<div class="checkbox">
  <label for="Fooditems"><b>Food items</b><p></p>
  <input type="checkbox" value="a" name="Fooditems[]">a Price per plate 120</label>
</div>
<div class="checkbox">
  <label><input type="checkbox" value="b" name="Fooditems[]">b</label>
</div>
<div class="checkbox disabled">
  <label><input type="checkbox" value="c" name="Fooditems[]">c</label>
</div>


<div class="container">
  <h2>Photography Packages </h2>
  
  
  <div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        
          <img src="img_avatar2.png" alt="Lights" style="width:100%">
          <div class="caption">
            <p>to select this select a in the option</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        
          <img src="/w3images/nature.jpg" alt="Nature" style="width:100%">
          <div class="caption">
            <p>to select this select a in the option</</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        
          <img src="/w3images/fjords.jpg" alt="Fjords" style="width:100%">
          <div class="caption">
            <p>to select this select a in the option</</p>
          </div>
        </a>
      </div>
    </div>
  </div>
</div>

	<label for="Photographypackages"><b>Photography Packages</b></label>
	<select name = "Photographypackages">
    <option value="select">select</option>
    <option value="a">a</option>
    <option value="b">b</option>
	<option value="c">c</option>
 	</select><p>
	
	
	<div class="container">
  
  <div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        
          <img src="/w3images/lights.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <p>to select this select a in the option</</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        
          <img src="/w3images/nature.jpg" alt="Nature" style="width:100%">
          <div class="caption">
            <p>to select this select a in the option</</p>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <
          <img src="/w3images/fjords.jpg" alt="Fjords" style="width:100%">
          <div class="caption">
            <p>to select this select a in the option</</p>
          </div>
        </a>
      </div>
    </div>
  </div>
</div>
	<label for="decoration"><b>Decoration</b></label>
    <select name = "decoration">
    <option value="select">select</option>
    <option value="a">a</option>
    <option value="b">b</option>
	<option value="c">c</option>
 	</select required><p>
	
    
	
	<input type="submit" name="submit" class="registerbtn" value="Order">
  </div>


</body>
</html>

